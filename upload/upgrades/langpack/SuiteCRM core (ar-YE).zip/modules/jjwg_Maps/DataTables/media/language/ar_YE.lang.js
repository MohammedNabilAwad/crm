{
    "sEmptyTable":     "لا توجد بيانات في الجدول",
    "sInfo":           "يتم عرض _START_ إلى _END_ من _TOTAL_ مدخل",
    "sInfoEmpty":      "عرض 0 إلى 0 من 0 مدخل",
    "sInfoFiltered":   "(تم فرزه من _MAX_ مجموع المدخلات)",
    "sInfoPostFix":    "",
    "sInfoThousands":  ",",
    "sLengthMenu":     "عرض _MENU_ المدخلات",
    "sLoadingRecords": "جاري التحميل...",
    "sProcessing":     "جاري المعالجة...",
    "sSearch":         "بحث:",
    "sZeroRecords":    "لم يتم الحصول على نتائج مطابقة",
    "oPaginate": {
        "sFirst":    "الأول",
        "sLast":     "الأخير",
        "sNext":     "اللاحق",
        "sPrevious": "السابق"
    },
    "oAria": {
        "sSortAscending":  ": فعّل لترتيب العمود تصاعديًا",
        "sSortDescending": ": فعّل لترتيب العمود تنازليًا"
    }
}
